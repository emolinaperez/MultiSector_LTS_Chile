# Industry and Mining energy model developed by Centro de Energia U. de Chile using RAND python framework
# version 0.7 september 2020

import os, os.path
import time
import pandas as pd
import numpy as np


#############################
#    INDUSTRY AND MINING    #
############################

def sm_industry_and_mining(df_in):

    # conversion factor Tcal to TJ
    fact = 4.184
    # conversion factor Tcal to GWh
    fact2 = 1.162952

    #SUB SECTOR: COPPER MINING MODEL - Mineria del cobre

    # Read input parameters defined in parameter_ranges.csv
    copper_production = np.array(df_in["copper_production"])
    copper_intensity = np.array(df_in["copper_intensity"])
    copper_frac_diesel = np.array(df_in["copper_frac_diesel"])
    copper_frac_natural_gas = np.array(df_in["copper_frac_natural_gas"])
    copper_frac_electric = np.array(df_in["copper_frac_electric"])
    copper_frac_hydrogen  = np.array(df_in["copper_frac_hydrogen"])
    copper_emission_fact_diesel = np.array(df_in["copper_emission_fact_diesel"])
    copper_emission_fact_natural_gas = np.array(df_in["copper_emission_fact_natural_gas"])

    # calculate demand in Tcal
    copper_dem_diesel = copper_production*copper_intensity*copper_frac_diesel
    copper_dem_natural_gas = copper_production*copper_intensity*copper_frac_natural_gas
    copper_dem_electric = copper_production*copper_intensity*copper_frac_electric
    copper_dem_hydrogen = copper_production*copper_intensity*copper_frac_hydrogen

    # calculate emission in millon tCO2
    copper_emission_diesel = copper_dem_diesel*fact*copper_emission_fact_diesel / (10 ** 9)
    copper_emission_natural_gas = copper_dem_natural_gas*fact*copper_emission_fact_natural_gas / (10 ** 9)
    copper_emission =copper_emission_diesel+copper_emission_natural_gas

    dict_emission = {"copper": copper_emission}
    dict_electric_demand = {"copper": copper_dem_electric*fact2}


    # SUB SECTOR: PULP ENERGY MODEL - Papel y Celulosa

    # Read input parameters defined in parameter_ranges.csv
    pulp_production = np.array(df_in["pulp_production"])
    pulp_intensity = np.array(df_in["pulp_intensity"])
    pulp_frac_diesel = np.array(df_in["pulp_frac_diesel"])
    pulp_frac_natural_gas = np.array(df_in["pulp_frac_natural_gas"])
    pulp_frac_electric = np.array(df_in["pulp_frac_electric"])
    pulp_frac_biomass = np.array(df_in["pulp_frac_biomass"])
    pulp_frac_hydrogen = np.array(df_in["pulp_frac_hydrogen"])
    pulp_emission_fact_diesel = np.array(df_in["pulp_emission_fact_diesel"])
    pulp_emission_fact_natural_gas = np.array(df_in["pulp_emission_fact_natural_gas"])

    # calculate demand in Tcal
    pulp_dem_diesel = pulp_production * pulp_intensity * pulp_frac_diesel
    pulp_dem_natural_gas = pulp_production * pulp_intensity * pulp_frac_natural_gas
    pulp_dem_electric = pulp_production * pulp_intensity * pulp_frac_electric
    pulp_dem_biomass = pulp_production * pulp_intensity * pulp_frac_biomass
    pulp_dem_hydrogen = pulp_production * pulp_intensity * pulp_frac_hydrogen

    # calculate emission in millon tCO2
    pulp_emission_diesel = pulp_dem_diesel * fact * pulp_emission_fact_diesel / (10 ** 9)
    pulp_emission_natural_gas = pulp_dem_natural_gas * fact * pulp_emission_fact_natural_gas / (10 ** 9)
    pulp_emission =pulp_emission_diesel+ pulp_emission_natural_gas

    # update
    dict_emission.update({"pulp": pulp_emission})
    dict_electric_demand.update({"pulp": pulp_dem_electric*fact2})

    # SUB SECTOR: Other industries - Industrias

    # Read input parameters defined in parameter_ranges.csv
    gdp = np.array(df_in["gdp"])
    other_industries_intensity = np.array(df_in["other_industries_intensity"])
    other_industries_frac_diesel = np.array(df_in["other_industries_frac_diesel"])
    other_industries_frac_natural_gas = np.array(df_in["other_industries_frac_natural_gas"])
    other_industries_frac_electric = np.array(df_in["other_industries_frac_electric"])
    other_industries_frac_biomass = np.array(df_in["other_industries_frac_biomass"])
    other_industries_frac_coal = np.array(df_in["other_industries_frac_coal"])
    other_industries_frac_hydrogen = np.array(df_in["other_industries_frac_hydrogen"])
    other_industries_emission_fact_diesel = np.array(df_in["other_industries_emission_fact_diesel"])
    other_industries_emission_fact_natural_gas = np.array(df_in["other_industries_emission_fact_natural_gas"])
    other_industries_emission_fact_coal = np.array(df_in["other_industries_emission_fact_coal"])

    # calculate demand in Tcal as function of GDP
    other_industries_dem_diesel = gdp * other_industries_intensity * other_industries_frac_diesel
    other_industries_dem_natural_gas = gdp * other_industries_intensity * other_industries_frac_natural_gas
    other_industries_dem_electric = gdp * other_industries_intensity * other_industries_frac_electric
    other_industries_dem_coal = gdp * other_industries_intensity * other_industries_frac_coal
    other_industries_dem_biomass = gdp * other_industries_intensity * other_industries_frac_biomass
    other_industries_dem_hydrogen = gdp * other_industries_intensity * other_industries_frac_hydrogen

    # calculate emission in millon tCO2
    other_industries_emission_diesel = other_industries_dem_diesel * fact * other_industries_emission_fact_diesel / (10 ** 9)
    other_industries_emission_natural_gas = other_industries_dem_natural_gas * fact * other_industries_emission_fact_natural_gas / (10 ** 9)
    other_industries_emission_coal = other_industries_dem_coal * fact * other_industries_emission_fact_coal / (10 ** 9)
    other_industries_emission = other_industries_emission_diesel+other_industries_emission_natural_gas+other_industries_emission_coal

    # update
    dict_emission.update({"other_industries": other_industries_emission})
    dict_electric_demand.update({"other_industries": other_industries_dem_electric*fact2})

    # SUB SECTOR: CEMENT Industry- Industria del cemento

    cement_production = np.array(df_in["cement_production"])
    cement_intensity = np.array(df_in["cement_intensity"])
    cement_frac_diesel = np.array(df_in["cement_frac_diesel"])
    cement_frac_natural_gas = np.array(df_in["cement_frac_natural_gas"])
    cement_frac_electric = np.array(df_in["cement_frac_electric"])
    cement_frac_biomass = np.array(df_in["cement_frac_biomass"])
    cement_frac_hydrogen = np.array(df_in["cement_frac_hydrogen"])
    cement_frac_coal = np.array(df_in["cement_frac_coal"])
    cement_frac_kerosene = np.array(df_in["cement_frac_kerosene"])
    cement_emission_fact_diesel = np.array(df_in["cement_emission_fact_diesel"])
    cement_emission_fact_natural_gas = np.array(df_in["cement_emission_fact_natural_gas"])
    cement_emission_fact_coal = np.array(df_in["cement_emission_fact_coal"])
    cement_emission_fact_kerosene = np.array(df_in["cement_emission_fact_kerosene"])

    # calculate demand in Tcal
    cement_dem_diesel = cement_production * cement_intensity * cement_frac_diesel
    cement_dem_natural_gas = cement_production * cement_intensity * cement_frac_natural_gas
    cement_dem_electric = cement_production * cement_intensity * cement_frac_electric
    cement_dem_biomass = cement_production * cement_intensity * cement_frac_biomass
    cement_dem_hydrogen = cement_production * cement_intensity * cement_frac_hydrogen
    cement_dem_coal = cement_production * cement_intensity * cement_frac_coal
    cement_dem_kerosene = cement_production * cement_intensity * cement_frac_kerosene

    # calculate emission in millon tCO2
    cement_emission_diesel = cement_dem_diesel * fact * cement_emission_fact_diesel / (10 ** 9)
    cement_emission_natural_gas = cement_dem_natural_gas * fact * cement_emission_fact_natural_gas / (10 ** 9)
    cement_emission_coal = cement_dem_coal * fact * cement_emission_fact_coal / (10 ** 9)
    cement_emission_kerosene = cement_dem_kerosene * fact * cement_emission_fact_kerosene / (10 ** 9)
    cement_emission = cement_emission_diesel+cement_emission_natural_gas+cement_emission_coal+cement_emission_kerosene

    # update
    dict_emission.update({"cement": cement_emission})
    dict_electric_demand.update({"cement": cement_dem_electric*fact2})


    # SUB SECTOR: IRON Industry- Minieria del hierro
    iron_production = np.array(df_in["iron_production"])
    iron_intensity = np.array(df_in["iron_intensity"])
    iron_frac_diesel = np.array(df_in["iron_frac_diesel"])
    iron_frac_natural_gas = np.array(df_in["iron_frac_natural_gas"])
    iron_frac_electric = np.array(df_in["iron_frac_electric"])
    iron_frac_biomass = np.array(df_in["iron_frac_biomass"])
    iron_frac_hydrogen = np.array(df_in["iron_frac_hydrogen"])
    iron_frac_coal = np.array(df_in["iron_frac_coal"])
    iron_emission_fact_diesel = np.array(df_in["iron_emission_fact_diesel"])
    iron_emission_fact_natural_gas = np.array(df_in["iron_emission_fact_natural_gas"])
    iron_emission_fact_coal = np.array(df_in["iron_emission_fact_coal"])

    # calculate demand in Tcal
    iron_dem_diesel = iron_production * iron_intensity * iron_frac_diesel
    iron_dem_natural_gas = iron_production * iron_intensity * iron_frac_natural_gas
    iron_dem_electric = iron_production * iron_intensity * iron_frac_electric
    iron_dem_biomass = iron_production * iron_intensity * iron_frac_biomass
    iron_dem_hydrogen = iron_production * iron_intensity * iron_frac_hydrogen
    iron_dem_coal = iron_production * iron_intensity * iron_frac_coal

    # calculate emission in millon tCO2
    iron_emission_diesel = iron_dem_diesel * fact * iron_emission_fact_diesel / (10 ** 9)
    iron_emission_natural_gas = iron_dem_natural_gas * fact * iron_emission_fact_natural_gas / (10 ** 9)
    iron_emission_coal = iron_dem_coal * fact * iron_emission_fact_coal / (10 ** 9)
    iron_emission = iron_emission_diesel+iron_emission_natural_gas+iron_emission_coal

    # update
    dict_emission.update({"iron": iron_emission})
    dict_electric_demand.update({"iron": iron_dem_electric*fact2})

    # SUB SECTOR: Steel Industry- Industria del acero
    steel_production = np.array(df_in["steel_production"])
    steel_intensity = np.array(df_in["steel_intensity"])
    steel_frac_diesel = np.array(df_in["steel_frac_diesel"])
    steel_frac_natural_gas = np.array(df_in["steel_frac_natural_gas"])
    steel_frac_electric = np.array(df_in["steel_frac_electric"])
    steel_frac_biomass = np.array(df_in["steel_frac_biomass"])
    steel_frac_hydrogen = np.array(df_in["steel_frac_hydrogen"])
    steel_frac_coal = np.array(df_in["steel_frac_coal"])
    steel_frac_kerosene = np.array(df_in["steel_frac_kerosene"])
    steel_emission_fact_diesel = np.array(df_in["steel_emission_fact_diesel"])
    steel_emission_fact_natural_gas = np.array(df_in["steel_emission_fact_natural_gas"])
    steel_emission_fact_coal = np.array(df_in["steel_emission_fact_coal"])
    steel_emission_fact_kerosene = np.array(df_in["steel_emission_fact_kerosene"])

    # calculate demand in Tcal
    steel_dem_diesel = steel_production * steel_intensity * steel_frac_diesel
    steel_dem_natural_gas = steel_production * steel_intensity * steel_frac_natural_gas
    steel_dem_electric = steel_production * steel_intensity * steel_frac_electric
    steel_dem_biomass = steel_production * steel_intensity * steel_frac_biomass
    steel_dem_hydrogen = steel_production * steel_intensity * steel_frac_hydrogen
    steel_dem_coal = steel_production * steel_intensity * steel_frac_coal
    steel_dem_kerosene = steel_production * steel_intensity * steel_frac_kerosene

    # calculate emission in millon tCO2
    steel_emission_diesel = steel_dem_diesel * fact * steel_emission_fact_diesel / (10 ** 9)
    steel_emission_natural_gas = steel_dem_natural_gas * fact * steel_emission_fact_natural_gas / (10 ** 9)
    steel_emission_coal = steel_dem_coal * fact * steel_emission_fact_coal / (10 ** 9)
    steel_emission_kerosene = steel_dem_kerosene * fact * steel_emission_fact_kerosene / (10 ** 9)
    steel_emission= steel_emission_diesel+steel_emission_natural_gas+steel_emission_coal+steel_emission_kerosene

    # update
    dict_emission.update({"steel": steel_emission})
    dict_electric_demand.update({"steel": steel_dem_electric*fact2})

    #return
    return dict_emission,dict_electric_demand