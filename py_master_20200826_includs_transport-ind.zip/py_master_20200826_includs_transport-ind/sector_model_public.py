# Residential energy model developed by Centro de Energia U. de Chile using RAND python framework
# version 0.7 september 2020

import os, os.path
import time
import pandas as pd
import numpy as np


###################
#    PUBLIC SECTOR    #
###################

#pending
def sm_public(df_in):

    public_emission=0.3
    public_dem_electric=3100
    dict_emission = {"public": residential_emission}
    dict_electric_demand={"public": public_dem_electric}

    # return
    return dict_emission,dict_electric_demand