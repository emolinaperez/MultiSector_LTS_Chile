# Transport energy model developed by Centro de Energia U. de Chile using RAND python framework
# version 0.7 september 2020

import os, os.path
import time
import pandas as pd
import numpy as np


###################
#    TRANSPORT    #
###################

def sm_transport(df_in):

    # conversion factor Tcal to TJ
    fact = 4.184
    # conversion factor Tcal to GWh
    fact2 = 1.162952

    ########################
    #    ROAD PASSENGER    #
    ########################

    #Read input parameters defined in parameter_ranges.csv
    pkm_light_veh = np.array(df_in["transport_pkm_light_veh"])
    frac_gasoline = np.array(df_in["transport_light_veh_frac_gasoline"])
    frac_diesel = np.array(df_in["transport_light_veh_frac_diesel"])
    frac_electric = np.array(df_in["transport_light_veh_frac_electric"])
    intensity_gasoline = np.array(df_in["transport_light_veh_intensity_gasoline"])
    intensity_diesel = np.array(df_in["transport_light_veh_intensity_diesel"])
    intensity_electric = np.array(df_in["transport_light_veh_intensity_electric"])
    occupancy_rate = np.array(df_in["transport_light_veh_occupancy_rate"])
    emission_fact_gasoline = np.array(df_in["transport_emission_fact_gasoline"])
    emission_fact_diesel = np.array(df_in["transport_emission_fact_diesel"])

    #calculate veh-km by technology
    veh_km_gasoline =pkm_light_veh*frac_gasoline/occupancy_rate
    veh_km_diesel = pkm_light_veh*frac_diesel/occupancy_rate
    veh_km_electric = pkm_light_veh*frac_electric/occupancy_rate

    #calculate demand in Tcal
    transport_dem_gasoline = veh_km_gasoline*10*intensity_gasoline/(10**9)
    transport_dem_diesel = veh_km_diesel*10*intensity_diesel/(10**9)
    transport_dem_electric = veh_km_electric*10*intensity_electric/(10**9)

    #calculate emission in millon tCO2
    transport_emission_gasoline = transport_dem_gasoline*fact*emission_fact_gasoline/(10**9)
    transport_emission_diesel = transport_dem_diesel*fact*emission_fact_diesel/(10**9)
    transport_emission =transport_emission_gasoline+ transport_emission_diesel

    ###########################
    #    OTHER MODES   #
    ###########################
    # Pending

    ###########################
    #    FREIGHT TRANSPORT    #
    ###########################

    # Pending

    ###########################
    #    MARITIME TRANSPORT    #
    ###########################

    # Pending

    ###########################
    #    AVIATION TRANSPORT    #
    ###########################

    # Pending

    #summary

    dict_emission = {"transport": transport_emission}
    dict_electric_demand = {"transport": transport_dem_electric*fact2}

    #return
    return dict_emission,dict_electric_demand
