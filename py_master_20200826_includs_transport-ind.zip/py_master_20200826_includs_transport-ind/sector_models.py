#import models here
from sector_model_agriculture import *
from sector_model_buildings import *
from sector_model_energy import *
from sector_model_industry import *
from sector_model_land_use import *
from sector_model_livestock import *
from sector_model_transport import *
from sector_model_industry_and_mining import *
from sector_model_commercial import *
from sector_model_residential2 import *
from sector_model_waste import *

